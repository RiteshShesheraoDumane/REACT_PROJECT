import React, { Component } from 'react';

export class Newsitem extends Component {
  render() {
    let { title, description, imageurl, newsurl,author,date } = this.props; // Added 'newsurl' destructuring
    return (
      <div className="my-3">
        <div className="card" style={{ width: "18rem" }}>
          <img
            src={!imageurl? "https://img.huffingtonpost.com/asset/6782dad4160000590e70afde.jpeg?cache=o24XWllQaH&ops=1200_630": imageurl || "https://via.placeholder.com/300x200"} // Fallback for missing image
            className="card-img-top"
            alt="News"
          />
          <div className="card-body">
            <h5 className="card-title">{title || "No Title Available"}</h5>
            <p className="card-text">{description || "No Description Available"}</p>
            <p className="card-text"><small className="text-body-secondary">By {!author?" unknown" : author} On {date}</small></p>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                 Google News
                  <span class="visually-hidden">unread messages</span>
             </span>
            <a
              href={newsurl || "#"}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-sm btn-primary"
            >
              Read More
            </a>
          </div>
        </div>
      </div>
    );
  }
}

export default Newsitem;