import React, { Component } from 'react';
import Newsitem from './Newsitem';

export class Newspaper extends Component {
  constructor() {
    super();
    console.log("Constructor called");
    this.state = {
      articles: [], // Initialize articles as an empty array
      loading: false,
      page: 1,
      totalResults: 0, // Initialize totalResults
    };
  }

  // Fetch articles from API
  fetchArticles = async (page) => {
    console.log(`Fetching articles for page: ${page}`);
    let url = ` https://newsapi.org/v2/top-headlines?country=us&apiKey=fa03a26543874a4fa146fe1c90030fcd &page=${page}&pageSize=${this.props.pageSize} `;
   // adi https://newsapi.org/v2/top-headlines?country=${country}&category=${category}&apiKey=fa03a26543874a4fa146fe1c90030fcd&page=${page + 1}&pageSize=${pageSize}
   // majhi https://newsapi.org/v2/top-headlines?country=us&apiKey=fa03a26543874a4fa146fe1c90030fcd &page=${page}&pageSize=${this.props.pageSize}
    this.setState({ loading: true });
    try {
      let data = await fetch(url);
      let parsedData = await data.json();
      console.log(parsedData);
      this.setState({
        articles: parsedData.articles || [], // Ensure articles is always an array
        totalResults: parsedData.totalResults || 0, // Handle undefined totalResults
        loading: false,
      });
    } catch (error) {
      console.error("Error fetching articles:", error);
      this.setState({ loading: false }); // Stop loading on error
    }
  };

  async componentDidMount() {
    this.fetchArticles(this.state.page);
  }

  handlePreviousClick = async () => {
    const prevPage = this.state.page - 1;
    this.setState({ page: prevPage });
    this.fetchArticles(prevPage);
  };

  handleNextClick = async () => {
    const nextPage = this.state.page + 1;
    if (nextPage <= Math.ceil(this.state.totalResults / this.props.pageSize)) {
      this.setState({ page: nextPage });
      this.fetchArticles(nextPage);
    } else {
      console.log("No more pages to fetch");
    }
  };

  render() {
    return (
      <div>
        <div className="container my-3">
          <h2 className="text-center">NewsMonkey - Top Headlines</h2>
          {this.state.loading ? (
            <h4 className="text-center">Loading...</h4>
          ) : (
            <div className="row">
              {this.state.articles.length > 0 ? (
                this.state.articles.map((element) => (
                  <div className="col-md-4" key={element.url}>
                    <Newsitem
                      title={
                        element.title
                          ? element.title.slice(0, 45) + "..."
                          : "No Title Available"
                      }
                      description={
                        element.description
                          ? element.description.slice(0, 88) + "..."
                          : "No Description Available"
                      }
                      imageurl={element.urlToImage}
                      newsurl={element.url}
                      author={element.author}date={element.publishedAt}
                    />
                  </div  >
                ))
              ) : (
                <h5 className="text-center">No articles available</h5>
              )}
            </div>
          )}
          <div className="container d-flex justify-content-between">
            <button
              disabled={this.state.page <= 1}
              type="button"
              className="btn btn-dark"
              onClick={this.handlePreviousClick}
            >
              &larr; Previous
            </button>
            <button
              disabled={
                this.state.page + 1 >
                Math.ceil(this.state.totalResults / this.props.pageSize)
              }
              type="button"
              className="btn btn-dark"
              onClick={this.handleNextClick}
            >
              Next &rarr;
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Newspaper;
