import React, { Component } from 'react'

export class Spinner extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default Spinner